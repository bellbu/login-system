package com.example.loginsystem.domain.admin;

public enum Authority { // 열거형(enum) 타입: 상수들의 집합을 이루는 자료형
    ROLE_USER,
    ROLE_ADMIN
}
