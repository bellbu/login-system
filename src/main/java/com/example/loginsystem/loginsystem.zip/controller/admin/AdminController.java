package com.example.loginsystem.controller.admin;

import com.example.loginsystem.domain.admin.Admin;
import com.example.loginsystem.dto.admin.response.CustomAdmin;
import com.example.loginsystem.service.AdminService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@Slf4j // log 객체를 자동 생성
@RequiredArgsConstructor // 필드 주입을 생성자 주입으로 자동 설정
@RestController("/admin")
public class AdminController { // JWT 토큰 생성 RestController

    private final AdminService adminService;

    /**
     * 인증된 사용자 정보 조회
     * @param customAdmin
     * @return
     */
//     @Secured("ROLE_USER")           // USER 권한 설정
    @GetMapping("/info")
    public ResponseEntity<?> adminInfo(@AuthenticationPrincipal CustomAdmin customAdmin) {

        log.info("::::: customUser :::::");
        log.info("customAdmin : "+ customAdmin);

        Admin admin = customAdmin.getAdmin();
        log.info("admin : " + admin);

        // 인증된 사용자 정보
        if( admin != null )
            return new ResponseEntity<>(admin, HttpStatus.OK);

        // 인증 되지 않음
        return new ResponseEntity<>("UNAUTHORIZED", HttpStatus.UNAUTHORIZED);
    }

/**
     * 회원가입
     * @param entity
     * @return
     * @throws Exception
     */
/*

    @PostMapping("")
    public ResponseEntity<?> join(@RequestBody Users user) throws Exception {
        log.info("[POST] - /users");
        int result = userService.insert(user);

        if( result > 0 ) {
            log.info("회원가입 성공! - SUCCESS");
            return new ResponseEntity<>("SUCCESS", HttpStatus.OK);
        }
        else {
            log.info("회원가입 실패! - FAIL");
            return new ResponseEntity<>("FAIL", HttpStatus.BAD_REQUEST);
        }
    }

    */
/**
     * 회원 정보 수정
     * @param user
     * @return
     * @throws Exception
     */
/*

    @Secured("ROLE_USER")           // USER 권한 설정
    @PutMapping("")
    public ResponseEntity<?> update(@RequestBody Users user) throws Exception {
        log.info("[PUT] - /users");
        int result = userService.update(user);

        if( result > 0 ) {
            log.info("회원수정 성공! - SUCCESS");
            return new ResponseEntity<>("SUCCESS", HttpStatus.OK);
        }
        else {
            log.info("회원수정 실패! - FAIL");
            return new ResponseEntity<>("FAIL", HttpStatus.BAD_REQUEST);
        }
    }

    */
/**
     * 회원 탈퇴
     * @param userId
     * @return
     * @throws Exception
     */
/*

    @Secured("ROLE_USER")          //  USER 권한 설정
    @DeleteMapping("/{userId}")
    public ResponseEntity<?> destroy(@PathVariable("userId") String userId) throws Exception {
        log.info("[DELETE] - /users/{userId}");

        int result = userService.delete(userId);

        if( result > 0 ) {
            log.info("회원삭제 성공! - SUCCESS");
            return new ResponseEntity<>("SUCCESS", HttpStatus.OK);
        }
        else {
            log.info("회원삭제 실패! - FAIL");
            return new ResponseEntity<>("FAIL", HttpStatus.BAD_REQUEST);
        }

    }

*/


}
