package com.example.loginsystem.dto.admin.response;

import com.example.loginsystem.domain.admin.Admin;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.Collections;
import java.util.stream.Collectors;

@RequiredArgsConstructor
@Data
public class CustomAdmin implements UserDetails {

    private final Admin admin;

    /**
     * 권한 getter 메소드
     * Admin 엔티티의 authority 필드를 SimpleGrantedAuthority로 매핑
     */
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        /*
        // 권한을 SimpleGrantedAuthority로 변환하여 반환
        return Collections.singletonList(new SimpleGrantedAuthority(admin.getAuthorities().toString()));
        */
        return admin.getAuthorities().stream()
                    .map(auth -> new SimpleGrantedAuthority(auth.name()))
                    .collect(Collectors.toList());
    }

    @Override
    public String getUsername() {
        return admin.getEmail();
    }

    @Override
    public String getPassword() {
        return admin.getPassword(); // 비밀번호 인증이 아닌 토큰 인증만 사용하는 경우 null
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return admin.getEmailVerified();
    }
}
