package com.example.loginsystem.security.custom;

import com.example.loginsystem.domain.admin.Admin;
import com.example.loginsystem.domain.admin.AdminRepository;
import com.example.loginsystem.dto.admin.response.CustomAdmin;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;

@Slf4j
@RequiredArgsConstructor // 의존성 자동 주입(필드 주입이 아닌 생성자 주입)
@Service
public class CustomAdminDetailService implements UserDetailsService {

    private final AdminRepository adminRepository;

    @Override
    @Transactional
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException { // loadUserByUsername(): 스프링 시큐리티가 사용자 인증 시 호출하는 메서드
        /*
        log.info("login - loadUserByUsername : " + email);
        return adminRepository.findByEmail(email)
                .map(this::createUserDetails) // = Optional.map(admin -> this.createUserDetails(admin)): DB에 관리자 존재하면 해당 값을 변환(매핑) / 즉, Optional<Admin> -> Optional<UserDetails>로 변환
                .orElseThrow(() -> new UsernameNotFoundException(email + " -> DB에서 관리자를 찾을 수 없습니다.")); // orElseThrow(): 사용자가 DB에 존재하지 않으면 예외 던짐
        */
        Admin admin = adminRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException(email + " -> DB에서 관리자를 찾을 수 없습니다."));
        return new CustomAdmin(admin);
    }

    /*
    // DB에 조회한 Admin 객체를 스프링 시큐리티의 UserDetails 객체로 변환
    private UserDetails createUserDetails(Admin admin) {
        GrantedAuthority grantedAuthority = new SimpleGrantedAuthority(admin.getAuthorities().toString()); // GrantedAuthority: 사용자 권한 나타내는 인터페이스
        return new User(  // User 객체: 스프링 시큐리티에서 제공하는 UserDetails의 구현체
                        String.valueOf(admin.getEmail()),
                        admin.getPassword(),
                        Collections.singleton(grantedAuthority)
                        );
    }
    */


}
