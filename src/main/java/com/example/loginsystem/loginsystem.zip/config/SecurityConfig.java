package com.example.loginsystem.config;

import com.example.loginsystem.security.custom.CustomAdminDetailService;
import com.example.loginsystem.security.jwt.filter.JwtAuthenticationFilter;
import com.example.loginsystem.security.jwt.filter.JwtRequestFilter;
import com.example.loginsystem.security.jwt.provider.JwtTokenProvider;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.security.servlet.PathRequest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

// SpringSecurity 5.4 이하
// @EnableWebSecurity
// public class SecurityConfig extends WebSecurityConfigurerAdapter { }
@Slf4j
@Configuration
@RequiredArgsConstructor
@EnableWebSecurity  // @EnableWebSecurity: 스프링 시큐리티를 활성화하고 기본 보안 설정을 적용
public class SecurityConfig {

    private final CustomAdminDetailService customAdminDetailService;
    private final JwtTokenProvider jwtTokenProvider;

    // Spring Security의 필터 체인 구성 정의
    // HttpSecurity: 보안 설정을 구성하는 객체(인증 및 인가 정책 정의).
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        // 폼 기반 로그인 비활성화: RESTful API에서는 JWT 등 Stateless 인증 방식을 사용하며 폼 로그인은 불필요
        http.formLogin((login) -> login.disable());

        // HTTP 기본 인증 비활성화: 보안상의 이유로 대부분 비활성화(Base64로 인코딩)
        http.httpBasic((basic) -> basic.disable());
        
        // CSRF 공격 방어 기능 비활성화: RESTful API는 주로 Stateless 방식으로 동작하므로 CSRF 방지 불필요
        http.csrf ((csrf) -> csrf.disable());

        // 필터 설정
        http.addFilterAt(new JwtAuthenticationFilter(authenticationManager, jwtTokenProvider), UsernamePasswordAuthenticationFilter.class) // 특정 위치에 커스텀 필터를 추가할 때 사용
            .addFilterBefore(new JwtRequestFilter(jwtTokenProvider), UsernamePasswordAuthenticationFilter.class); // 지정된 필터 앞에 새로운 필터를 추가

        // 인가 설정
        http.authorizeHttpRequests(authorizeRequests -> authorizeRequests
                                                        .requestMatchers(PathRequest.toStaticResources().atCommonLocations()).permitAll() // CSS, JS, 이미지 같은 정적 리소스 접근 모든 사용자에게 허용
                                                        .requestMatchers("/").permitAll() // 루트 경로("/") 모든 사용자에게 허용
                                                        .requestMatchers("/login").permitAll()
                                                        .requestMatchers("/user/**").hasAnyRole("USER", "ADMIN")
                                                        .requestMatchers("/admin/**").hasAnyRole("ADMIN")
                                                        .anyRequest().authenticated() // 나머지 요청은 인증된 사용자만 접근 가능
                                    );

        // 인증 방식 설정
        // userDetailsService(): 인증 과정에서 customUserDetailService 사용하여 관리자 정보를 불러오는 메소드
        // 스프링 시큐리티가 customUserDetailService를 통해 loadUserByUsername() 메서드를 호출하도록 설정
        http.userDetailsService(customAdminDetailService);

        return http.build(); // 정의한 보안 설정으로 보안 필터 체인 생성
    }

    // 암호화 알고리즘 방식: Bcrypt
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    // AuthenticationManager 빈 등록
    private AuthenticationManager authenticationManager;

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration) throws Exception {
        this.authenticationManager = authenticationConfiguration.getAuthenticationManager();
        return authenticationManager;
    }
}
